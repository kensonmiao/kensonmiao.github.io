from lib.resolvers import icdrama, videobug, hdplay
